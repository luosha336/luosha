=======
gpu_x86
=======

x86 implementation of GPU routines. For use when GPUs are not available.
