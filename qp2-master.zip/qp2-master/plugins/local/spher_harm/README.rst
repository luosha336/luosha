==========
spher_harm
==========

Routines for spherical Harmonics evaluation in real space. 
The main routine is "spher_harm_func_r3(r,l,m,re_ylm, im_ylm)".  
The test routine is "test_spher_harm" where everything is explained in details. 
