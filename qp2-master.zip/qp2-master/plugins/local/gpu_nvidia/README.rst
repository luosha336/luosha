==========
gpu_nvidia
==========

Nvidia implementation of GPU routines. Uses CUDA and CUBLAS libraries.
