======
pseudo
======

This module defines the |EZFIO| parameters of the effective core potentials.
