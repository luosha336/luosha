=========
dress_zmq
=========

Module to facilitate the construction of modules using dressed
Hamiltonians, parallelized with |ZeroMQ|.

