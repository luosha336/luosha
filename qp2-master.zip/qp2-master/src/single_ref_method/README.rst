=================
single_ref_method
=================

Include this module for single reference methods.
Using this module, the only generator determinant is the Hartree-Fock determinant.

