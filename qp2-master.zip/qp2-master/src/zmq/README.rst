===
zmq
===

Definition of |ZeroMQ| sockets and messages.


