======
trexio
======

Module for handling TREXIO files.
See https://github.com/trex-coe/trexio
