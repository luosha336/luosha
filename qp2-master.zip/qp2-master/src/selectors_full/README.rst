==============
selectors_full
==============

All the determinants are possible selectors. Only the largest contributions are kept, where
a threshold is applied to the squared norm of the wave function, with the :option:`determinants
threshold_selectors` flag.
