======
basis
======

This module contains the basis set information, which will then be used to build the atomic orbitals.



