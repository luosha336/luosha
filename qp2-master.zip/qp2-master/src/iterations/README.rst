==========
iterations
==========

Module which saves the computed energies for an extrapolation to
the |FCI| limit.
