int mkl_serv_intel_cpu_true() {
  return 1;
}


