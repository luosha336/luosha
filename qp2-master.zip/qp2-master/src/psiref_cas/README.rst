==========
psiref_cas
==========

Reference wave function is defined as a |CAS| wave function.
This module is required for |CAS-SD|, |MRPT| or |MRCC|.

