============
two_body_rdm
============

Contains the two rdms $\alpha\alpha$, $\beta\beta$ and $\alpha\beta$ stored as
arrays, with pysicists notation, consistent with the two-electron integrals in the MO basis.


