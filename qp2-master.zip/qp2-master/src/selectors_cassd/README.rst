===============
selectors_cassd
===============

Selectors for |CAS-SD| calculations. The selectors are defined as first the
generators from :ref:`module_generators_cas`, and then the rest of the wave function.
