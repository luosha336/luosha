  logical, parameter :: debug=.False.
  double precision, parameter :: pi = 3.1415926535897932d0
