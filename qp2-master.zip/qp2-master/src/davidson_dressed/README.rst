================
davidson_dressed
================

Davidson with single-column dressing.

