===========
hamiltonian
===========

Parameters of the Hamiltonian.
