==============
on_top_density
==============

This plugin proposes different routines/providers to compute the on-top pair density of a CAS-based wave function. 

This means that all determinants in psi_det must belong to an active-space. 

As usual, see the file "example.irp.f" to get introduced to the main providers/routines.
