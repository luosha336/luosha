===============
generators_full
===============

Module defining the generator determinants as all the determinants of the
variational space.

This module is intended to be included in the :file:`NEED` file to define
a full set of generators.
