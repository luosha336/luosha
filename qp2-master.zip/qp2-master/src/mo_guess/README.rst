========
mo_guess
========

Guess for |MOs|.

