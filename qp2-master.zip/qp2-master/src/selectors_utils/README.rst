===============
selectors_utils
===============

Helper functions for selectors.

