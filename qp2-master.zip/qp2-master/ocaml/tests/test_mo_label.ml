let () =
  let m = MO_label.of_string "canonical" in
  let s = MO_label.to_string m in
  print_string s
;;
