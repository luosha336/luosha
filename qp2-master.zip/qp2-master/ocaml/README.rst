===============
OCaml scripts
===============

This directory contains all the scripts that control the input/output
with the user.

All executables start with `qp_` and all tests start with `test_`. Modules
file names start with a capital letter.

Info on how to extend the `qp_edit` tool is given in
`README_qp_edit.rst <https://github.com/LCPQ/quantum_package/blob/master/ocaml/README_qp_edit.rst>`_.

