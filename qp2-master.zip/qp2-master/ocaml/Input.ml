open Qputils;;
open Qptypes;;

include Input_ao_basis;;
include Input_bitmasks;;
include Input_determinants_by_hand;;
include Input_electrons;;
include Input_mo_basis;;
include Input_nuclei_by_hand;;
include Input_auto_generated;;
