This directory contains all the files to be sourced when the |QP| environment is loaded.
