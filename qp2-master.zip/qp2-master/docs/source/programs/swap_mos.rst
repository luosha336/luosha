.. _swap_mos: 
 
.. program:: swap_mos 
 
======== 
swap_mos 
======== 
 
 
 
 
 Swaps the indices of two molecular orbitals 
 
 Needs: 
 
 .. hlist:: 
    :columns: 3 
 
    * :c:data:`ao_num` 
    * :c:data:`mo_coef` 
 
 Calls: 
 
 .. hlist:: 
    :columns: 3 
 
    * :c:func:`save_mos` 
