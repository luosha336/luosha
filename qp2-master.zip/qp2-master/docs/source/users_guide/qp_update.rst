.. _qp_update:

=========
qp_update
=========

.. program:: qp_update

This command makes an update of the |QP| to the latest stable version.

Usage
-----

.. code:: bash

    qp_update [-h]

