.. _module_davidson_dressed: 
 
.. program:: davidson_dressed 
 
.. default-role:: option 
 
================
davidson_dressed
================

Davidson with single-column dressing.

 
