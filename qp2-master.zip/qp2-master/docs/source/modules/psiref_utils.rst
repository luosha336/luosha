.. _module_psiref_utils: 
 
.. program:: psiref_utils 
 
.. default-role:: option 
 
============
psiref_utils
============


Utilities related to the use of a reference wave function. This module
needs to be loaded with any `psi_ref_*` module.


 
