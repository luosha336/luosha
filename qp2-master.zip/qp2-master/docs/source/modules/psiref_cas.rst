.. _module_psiref_cas: 
 
.. program:: psiref_cas 
 
.. default-role:: option 
 
==========
psiref_cas
==========

Reference wave function is defined as a |CAS| wave function.
This module is required for |CAS-SD|, |MRPT| or |MRCC|.

 
