.. _module_single_ref_method: 
 
.. program:: single_ref_method 
 
.. default-role:: option 
 
=================
single_ref_method
=================

Include this module for single reference methods.
Using this module, the only generator determinant is the Hartree-Fock determinant.

 
