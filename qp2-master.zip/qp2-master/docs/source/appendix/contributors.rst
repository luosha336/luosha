============
Contributors
============

The |qp| is maintained by

Anthony Scemama
  | `Laboratoire de Chimie et Physique Quantiques <http://www.lcpq.ups-tlse.fr/>`_,
  | CNRS - Université Paul Sabatier
  | Toulouse, France
  | scemama@irsamc.ups-tlse.fr


Emmanuel Giner
  | `Laboratoire de Chimie Theorique <http://www.lct.jussieu.fr/>`_
  | CNRS - Sorbonne Université
  | Paris, France
  | emmanuel.giner@lct.jussieu.fr


The following people have contributed to this project (by alphabetical order):

* Abdallah Ammar
* Thomas Applencourt
* Roland Assaraf
* Pierrette Barbaresco
* Anouar Benali
* Chandler Bennet
* Michel Caffarel
* Vijay Gopal Chilkuri
* Yann Damour
* Grégoire David
* Amanda Dumi
* Anthony Ferté
* Madeline Galbraith
* Yann Garniron
* Kevin Gasperich
* Fabris Kossoski
* Pierre-François Loos
* Jean-Paul Malrieu
* Antoine Marie
* Barry Moore
* Julien Paquier
* Barthélémy Pradines
* Peter Reinhardt
* Nicolas Renon
* Lorenzo Tenti
* Julien Toulouse
* Diata Traoré
* Mikaël Véril


If you have contributed and don't appear in this list, please modify the file
`$QP_ROOT/docs/source/appendix/contributors.rst`
and submit a pull request.

