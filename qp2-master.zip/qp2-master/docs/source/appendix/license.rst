License
=======

.. include:: LICENSE
   :literal:




