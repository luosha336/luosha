Requirements for the documentation
==================================

      pip install sphinx
      pip install sphinx_rtd_theme
      pip install sphinxcontrib-bibtex
