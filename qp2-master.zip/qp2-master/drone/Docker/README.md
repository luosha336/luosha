Docker files to build the containers used with DroneCI.

Example:
```
docker build -t ubuntu/qp2_env .

```

