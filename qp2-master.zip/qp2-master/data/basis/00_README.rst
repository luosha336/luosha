${QP_ROOT}/data/basis contains basis set files. Install here the basis set
files you use regularly. GAMESS US format is required.

Basis sets can be easily downloaded from the Basis Set Exchange Website
https://www.basissetexchange.org , or using the command-line tool they
provide.

In addition, you can use the qp_basis tool to install new basis sets.