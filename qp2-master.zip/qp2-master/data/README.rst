====
Data
====


This directory contains all the data files needed for the Quantum Package.

The `basis` directory contains some of the most popular basis sets, and the
`pseudo` directory contains pseudopotential data.
